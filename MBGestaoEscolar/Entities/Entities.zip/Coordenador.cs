﻿namespace MBGestaoEscolar.Entities
{
    public class Coordenador:Pessoa
    {
        public int CoordenadorId { get; set; }
    }
}
